<?php
defined( 'ABSPATH' ) or exit;
class WC_TTR {
    /** @var WC_TTR single instance of this plugin */
	protected static $instance;
    public $plugin_path;
    protected $wc_ttr_admin;
    protected $wc_ttr_api;

    public function __construct(){
        $this->plugin_path = plugin_dir_path( __FILE__ );
        $this->includes();
    }

    public function includes(){
    
        require_once($this->plugin_path."includes/class-ttr-wc-admin.php");
        $this->wc_ttr_admin = new WC_TTR_Admin;

        require_once($this->plugin_path."includes/admin/api/class-wc-ttr-api.php");
        $this->wc_ttr_api= new WC_TTR_API;

    }
    
    public function get_plugin_path(){
        return $this->plugin_path;
    }

    public function get_api(){
        return $this->wc_ttr_api;
    }
    
    /**
	 * WC_TTR Instance
	 *
	 * @return WC_TTR
	 */
	public static function instance() {

		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}
}

/**
 * Returns the WC_TTR Singleton
 *
 * @return WC_TTR
 */
function wc_ttr() {

	return WC_TTR::instance();
}