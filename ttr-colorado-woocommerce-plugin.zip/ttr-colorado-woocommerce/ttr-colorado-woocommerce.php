<?php
/**
 * Plugin Name: TTR Colorado Woocommerce
 * Description: Open source plugin to calculate tax for Colorado shops using Woocommerce and TTR's taxrates API.
 * Version: 0.4.0
 *
 * License: GNU General Public License v2.0 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 *
 */

defined( 'ABSPATH' ) or exit;

// Required functions
if ( ! function_exists( 'woothemes_queue_update' ) ) {
	require_once( plugin_dir_path( __FILE__ ) . 'woo-includes/woo-functions.php' );
}

// WC active check
if ( ! is_woocommerce_active() ) {
	return;
}

/** Currently just testing compatibility */
class WC_TTR_Loader {

    //Copied from avatax plugin, will need to test later

    /** php version required*/
	const MINIMUM_PHP_VERSION = '7.0';

	/** wordpress version required */
	const MINIMUM_WP_VERSION = '5.2';

	/** wc version required */
	const MINIMUM_WC_VERSION = '3.5';

    /** plugin name */
    const PLUGIN_NAME = 'TTR Colorado WooCommerce';

    /** Singleton instance of class */
    protected static $instance;

    /** @var array admin notices */
	protected $notices = array();

    protected function __construct() {

		register_activation_hook( __FILE__, array( $this, 'activation_check' ) );

        add_action( 'admin_init', array( $this, 'check_environment' ) );
		add_action( 'admin_init', array( $this, 'add_plugin_notices' ) );

		add_action( 'admin_notices', array( $this, 'admin_notices' ), 15 );

		// if the environment check doesn't fail, initialize the plugin
		if ( $this->is_environment_compatible() ) {

			add_action( 'plugins_loaded', array( $this, 'init_plugin' ) );
		}

    }

    
    /**
	 * Initializes the plugin.
	 *
	 */
	public function init_plugin() {

		if ( ! $this->plugins_compatible() ) {
			return;
		}
	
		// TODO: load the main plugin class 
		require_once( plugin_dir_path( __FILE__ ) . 'class-wc-ttr.php' );

		// fire it up!
		wc_ttr();
	}

    
	/**
	 * Check environment, deactivate if not compatible
	 *
	 */
    protected function activation_check() {
        if ( ! $this->is_environment_compatible() ) {

			$this->deactivate_plugin();

			wp_die( self::PLUGIN_NAME . ' could not be activated. ' . $this->get_environment_message() );
		}
		
	
    }

    /**
	 * Checks the environment on loading WordPress, just in case the environment changes after activation.
	 *
	 */
	public function check_environment() {

		if ( ! $this->is_environment_compatible() && is_plugin_active( plugin_basename( __FILE__ ) ) ) {

			$this->deactivate_plugin();

			$this->add_admin_notice( 'bad_environment', 'error', self::PLUGIN_NAME . ' has been deactivated. ' . $this->get_environment_message() );
		}
	}


    /**
	 * Adds an admin notice to be displayed.
	 *
	 *
	 * @param string $slug the notice message slug
	 * @param string $class the notice message class (Can make this whatever)
	 * @param string $message the notice message body
	 */
	public function add_admin_notice( $slug, $class, $message ) {

		$this->notices[ $slug ] = array(
			'class'   => $class,
			'message' => $message,
		);
	}


	/**
	 * Displays any admin notices
	 *
	 */
	public function admin_notices() {

		foreach ( (array) $this->notices as $notice_key => $notice ) {

			?>
			<div class="<?php echo esc_attr( $notice['class'] ); ?>">
				<p><?php echo wp_kses( $notice['message'], array( 'a' => array( 'href' => array() ) ) ); ?></p>
			</div>
			<?php

		}
	}

    
    /**
	 * Adds notices for out-of-date WordPress and/or WooCommerce versions.
	 *
	 */
	public function add_plugin_notices() {

		if ( ! $this->is_wp_compatible() ) {

			$this->add_admin_notice( 'update_wordpress', 'error', sprintf(
				'%s requires WordPress version %s or higher. Please %supdate WordPress &raquo;%s to ensure proper functionality.',
				'<strong>' . self::PLUGIN_NAME . '</strong>',
				self::MINIMUM_WP_VERSION,
				'<a href="' . esc_url( admin_url( 'update-core.php' ) ) . '">', '</a>'
			) );
		}

		if ( ! $this->is_wc_compatible() ) {

			$this->add_admin_notice( 'update_woocommerce', 'error', sprintf(
				'%1$s requires WooCommerce version %2$s or higher. Please %3$supdate WooCommerce%4$s to the latest version, or %5$sdownload the minimum required version &raquo;%6$s',
				'<strong>' . self::PLUGIN_NAME . '</strong>',
				self::MINIMUM_WC_VERSION,
				'<a href="' . esc_url( admin_url( 'update-core.php' ) ) . '">', '</a>',
				'<a href="' . esc_url( 'https://downloads.wordpress.org/plugin/woocommerce.' . self::MINIMUM_WC_VERSION . '.zip' ) . '">', '</a>'
			) );
		}
	}


    /**
	 * Determines if current woocommerce plugin and wordpress verisons are compatible
	 *
	 *
	 * @return bool
	 */
	protected function plugins_compatible() {

		return $this->is_wp_compatible() && $this->is_wc_compatible();
	}


    /**
	 * Determines if the WordPress compatible.
	 *
	 *
	 * @return bool
	 */
	protected function is_wp_compatible() {

		if ( ! self::MINIMUM_WP_VERSION ) {
			return true;
		}

		return version_compare( get_bloginfo( 'version' ), self::MINIMUM_WP_VERSION, '>=' );
	}


    /**
	 * Determines if the WooCommerce version is compatible.
	 *
	 *
	 * @return bool
	 */
	protected function is_wc_compatible() {

		if ( ! self::MINIMUM_WC_VERSION ) {
			return true;
		}

		return defined( 'WC_VERSION' ) && version_compare( WC_VERSION, self::MINIMUM_WC_VERSION, '>=' );
	}


    /**
	 * Determines if the server environment is compatible with this plugin.
     * Currently just checking php version
	 *
	 * Override this method to add checks for more than just the PHP version.
	 *
	 * @return bool
	 */
	protected function is_environment_compatible() {

		return version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '>=' );
	}


    /**
	 * Gets the message for display when the environment is incompatible with this plugin.
	 *
	 *
	 * @return string
	 */
	protected function get_environment_message() {

		return sprintf( 'The minimum PHP version required for this plugin is %1$s. You are running %2$s.', self::MINIMUM_PHP_VERSION, PHP_VERSION );
	}


	/**
	 * Deactivates the plugin.
	 *
	 */
	protected function deactivate_plugin() {

		deactivate_plugins( plugin_basename( __FILE__ ) );

		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}
    
	}


    /**
	 * Cloning instances is forbidden due to singleton pattern.
	 *
	 */
	public function __clone() {

		_doing_it_wrong( __FUNCTION__, sprintf( 'You cannot clone instances of %s.', get_class( $this ) ), '1.0.0' );
	}


	/**
	 * Unserializing instances is forbidden due to singleton pattern.
	 *
	 */
	public function __wakeup() {

		_doing_it_wrong( __FUNCTION__, sprintf( 'You cannot unserialize instances of %s.', get_class( $this ) ), '1.0.0' );
	}


    /**
	 * Gets the instance.
	 *
	 * Ensures only one instance can be loaded.
	 *
	 *
	 * @return WC_TTR_Loader
	 */
	public static function instance() {

		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}
}

//entry
WC_TTR_Loader::instance();