<?php

class WC_TTR_API{
    protected $request_handler;

    //move to handler
    protected $lines;
    public function __construct(){

       
        require_once( plugin_dir_path( __FILE__ ) . 'class-wc-ttr-api-request.php' );
        $this->request_handler = new WC_TTR_API_Request();
	
		
        add_filter( 'woocommerce_matched_tax_rates', '__return_empty_array' );


		// set matched tax rates throughout the store to those estimated by plugin
		add_filter( 'woocommerce_matched_tax_rates', array( $this, 'set_matched_tax_rates' ), 15, 5 );

	    add_filter( 'woocommerce_rate_code', array( $this, 'set_tax_rate_code' ), 10, 2 );
		
        add_filter('woocommerce_calculate_item_totals_taxes',  array( $this, 'get_item_totals' ), 10, 3);

	    // Set the plugin rate code label
		add_filter( 'woocommerce_cart_tax_totals', array( $this, 'set_tax_rate_labels' ), 10, 2 );

		// set matched tax rates throughout the store to those estimated by plugin
		add_filter( 'woocommerce_matched_tax_rates', array( $this, 'set_matched_tax_rates' ), 15, 5 );
		
		// Set the order item tax rate ID
		add_filter( 'woocommerce_order_item_get_rate_id', array( $this, 'set_order_item_tax_rate_id' ), 10, 2 );
	

    }

	public function set_order_item_tax_rate_id( $rate_id, $item ) {

		$rate_id = $item->get_name();
		return $rate_id;
	}

	public function set_tax_rate_code( $code_string, $key ) {
		if (!is_cart()){
		$code_string = $key;

		return $code_string;
		}
		return;
	}


    public function calculate_cart_tax(&$cart){
        $ttr_codes = [];
        $items = $cart->get_cart_contents();
        foreach($items as $item){
            if (isset($item['product_id']) && null !== $ttr_code = get_post_meta($item['product_id'], '_wc_ttr_code')){
                $ttr_codes[] = $ttr_code[0];
            }
        }
          
            
        $destination_address = $this->get_destination_address();

        foreach($ttr_codes as $item_id){
           $response = $this->request_handler->get_item_address_response($destination_address,$item_id);
        }

    }
    
	public function set_matched_tax_rates( $matched_tax_rates ) {

		if ( is_admin() ) {
			return $matched_tax_rates;
		}

		$display_setting = wc_prices_include_tax() ? 'excl' : 'incl';

		if ( ! is_cart() && ! is_checkout() && $display_setting !== get_option( 'woocommerce_tax_display_shop' ) ) {
			return $matched_tax_rates;
		}

		$rates = $this->get_address_rates($this->get_destination_address());

		foreach ( $rates as $rate ) {
            $label = $rate['type'].' - '.$rate['jurisdiction'];
			
			$matched_tax_rates[ $label] = array(
				'rate'     => $rate['value'] * 100,
				'label'    => ucfirst($label),
				'shipping' => 'yes', 
				'compound' => 'no',
			);
		}
      
		
		return $matched_tax_rates;
	}
   


    public function get_destination_address(){
      
        return( WC()->customer->get_shipping_address().' '.WC()->customer->get_shipping_address_2().' '.WC()->customer->get_shipping_city().' '.
        WC()->customer->get_shipping_state().' '.WC()->customer->get_shipping_country().' '.WC()->customer->get_shipping_postcode());
    }
    
	public function get_lines() {

		$lines = array();


		foreach ( $this->lines as $line ) {

			$lines[] = array(
				'id'          => $line->lineNumber,
				'sku'         => isset( $line->itemCode ) ? $line->itemCode : '',
				'amount'      => $line->lineAmount,
				'tax'         => $line->tax,
				'code'        => $line->taxCode,
				'rates'       => $this->build_rates( $line->details, $duplicate_tax_rate_codes ),
				'origin'      => isset( $line->originAddressId ) ? $this->get_origin_address( $line ) : array(),
				'destination' => isset( $line->destinationAddressId ) ? $this->get_destination_address( $line ) : array(),
			);
		}

		return $lines;
	}

	

    public function get_item_totals($arg, $arg1, $arg2){
		if (!is_cart()){
        $rates = [];
        $total = 0;
       
        foreach ($arg1 as $item){

            if (is_array($item) && isset($item['product_id'])){
				
                $ttr_code = get_post_meta($item['product_id'], '_wc_ttr_code');

                if (null !== $ttr_code && !empty($ttr_code)){
                   
                    $product = wc_get_product( $item['product_id'] );
                    $total = ($product->get_price() * $item['quantity']) * 100;
                    $id = $ttr_code[0];
                    $address = $this->get_destination_address();
                    $rates = $this->get_item_rates($address, $ttr_code[0]);
					
                }
            }   
        }

        return  WC_Tax::calc_tax( ($total), $rates);
	}
    }


    protected function get_item_rates($address,$ttr_id){
        $rates = [];
        $response = $this->request_handler->get_item_address_response($address,$ttr_id);
        $response_array = json_decode(wp_remote_retrieve_body($response),true);
		$total = 0;
        foreach($response_array['salesTax'] as $rate){

			$total +=  $rate['answer'] == 'taxable' ? ($rate['value'] * 100) : 0;

            $label = ucfirst($rate['type']).' Tax - '.$rate['jurisdiction'];

			$rate_object = array(
				'rate'     => $rate['answer'] == 'taxable' ? ($rate['value'] * 100) : 0,
				'label'    => ucfirst($label),
				'shipping' => 'yes',
				'compound' => 'no');

				if (get_option( 'wc_ttr_api_tax_breakdown') == 'yes'){
           			 $rates[$label] = $rate_object;
				}

        }

		if (get_option( 'wc_ttr_api_tax_breakdown') != 'yes'){
			$rate_object = array(
					'rate'     =>$total,
					'label'    => "Tax",
					'shipping' => 'yes',
					'compound' => 'no');

			$rates['Tax'] = $rate_object;
		}
        return $rates;
    }

    protected function get_address_rates($address){
        $rates= [];
        $response = $this->request_handler->get_address_response($address);
        $response_array = json_decode(wp_remote_retrieve_body($response),true);

        return $response_array['salesTax'];
        
    }


	public function set_tax_rate_labels( $tax_totals, $cart ) {
		
		
		foreach($tax_totals as $tax){
	
			$tax->label = $tax->tax_rate_id;
		}

		return $tax_totals;
	}


}

