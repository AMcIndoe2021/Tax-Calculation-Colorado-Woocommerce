<?php
defined( 'ABSPATH' ) or exit;

class WC_TTR_Checkout_Handler {
	const MB_ENCODING = 'UTF-8';
	
    public function __construct(){
        // calculate the tax based on the cart at checkout
        add_action( 'woocommerce_after_calculate_totals', [ $this, 'calculate_taxes' ], 999 );
    }

	public function calculate_taxes( $cart ) {
		//$cart->set_cart_contents_tax('.59');
        $content = $cart->get_cart_contents();
        $this->set_product_taxes( $cart );
	}

	protected function reset_cart_taxes( \WC_Cart $cart ) {

		$recurring_carts = isset( $cart->recurring_carts ) ? $cart->recurring_carts : null;

		remove_action( 'woocommerce_after_calculate_totals', [ $this, 'calculate_taxes' ], 999 );
		add_filter( 'woocommerce_find_rates', [ $this, 'remove_estimated_tax_rates' ] );

		$cart->calculate_totals();

		remove_filter( 'woocommerce_find_rates', [ $this, 'remove_estimated_tax_rates' ] );
		add_action( 'woocommerce_after_calculate_totals', [ $this, 'calculate_taxes' ], 999 );

		if ( $recurring_carts ) {
			$cart->recurring_carts = $recurring_carts;
		}
	}

	
	public function remove_estimated_tax_rates( $matched_tax_rates ) {

		foreach ( $matched_tax_rates as $code => $rate ) {

			if ( self::str_starts_with( $code, 'TTR')){
				unset( $matched_tax_rates[ $code ] );
			}
		}

		return $matched_tax_rates;
	}

	public static function str_to_ascii( $string ) {

		// strip ASCII chars 32 and under
		$string = filter_var( $string, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_LOW );

		// strip ASCII chars 127 and higher
		return filter_var( $string, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH );
	}

	public static function str_starts_with( $haystack, $needle ) {

		if ( self::multibyte_loaded() ) {

			if ( '' === $needle ) {
				return true;
			}

			return 0 === mb_strpos( $haystack, $needle, 0, self::MB_ENCODING );

		} else {

			$needle = self::str_to_ascii( $needle );

			if ( '' === $needle ) {
				return true;
			}

			return 0 === strpos( self::str_to_ascii( $haystack ), self::str_to_ascii( $needle ) );
		}
	}

	protected static function multibyte_loaded() {

		return extension_loaded( 'mbstring' );
	}


	protected function set_product_taxes( WC_Cart $cart ) {

		$subtotal   = $cart->get_subtotal();
		$cart_taxes = $cart->get_cart_contents_taxes();
		$cart->set_subtotal_tax($cart_taxes);
		$contents = $cart->get_cart_contents;
		if (is_array($contents)){

			foreach($contents as $id => $value){
				if (isset($id['product_id'])){
					$cart->cart_contents[$id]['line_tax_data']['subtotal'] = $cart_taxes;
					$cart->set_subtotal_tax( $cart->get_subtotal_tax() + 50);
				}
			}
					
		}
		
		$cart->set_cart_contents_taxes( $cart_taxes );

	}
}