<?php
defined( 'ABSPATH' ) or exit;

class WC_TTR_API_Request{
    protected $api_key;
    protected $request_uri = 'https://api.ttr.services/v1/automation.rates.list';

    public function __construct(){
    }

    public function key_validity_check(){
        $response = wp_remote_post( $this->request_uri, array(
            'method'      => 'POST',
            'Content-Type' => 'application/json',
            'headers'     => array(
                'Authorization' => 'Bearer '.get_option( 'wc_ttr_api_license_key' )
            ),
            'body'        => '',
            )
        );
        if (wp_remote_retrieve_response_code($response) == 400){
            return true;
        }
        if ( is_wp_error( $response ) ) {
            return false;
            
        };
            
    }
    
    /** 
     * Get tax rates for address
     * 
     * @param string $address 
     * @return response response object
     */
    public function get_address_response($address){
        $data_array = array('address' => $address);
        $json = json_encode($data_array);
        return $this->send_request($json);
    }


    /** 
     * Get tax rates for coordinates
     * 
     * @param string $coordinates 
     * @return response response object
     */
    public function get_coordinate_response($address){

    }


    /** 
     * Get service rates for address
     * 
     * @param string $address 
     * @param string $item_id
     * @return response response object
     */
    public function get_item_address_response($address, $item_id){
        $data_array = array('address' => $address, 'product_service_id' => $item_id);
        $json = json_encode($data_array);
        return $this->send_request($json);
    }


    /** 
     * Get service rates for coordinates
     * 
     * @param string $address 
     * @param string $item_id
     * @return response response object
     */
    public function get_item_coordinate_response($coordinates, $item_id){

    }


    /** 
     * Send request to ttr servers
     * 
     * @param json_object $data
     * 
     * @return response response object
     */
    protected function send_request($json_data){
        $response = wp_remote_post( $this->request_uri, array(
            'method'      => 'POST',
            'Content-Type' => 'application/json',
            'headers'     => array(
                'Authorization' => 'Bearer '.get_option( 'wc_ttr_api_license_key' )
            ),
            'body'        => $json_data,
            )
        );

    
        return $response;
    }

}