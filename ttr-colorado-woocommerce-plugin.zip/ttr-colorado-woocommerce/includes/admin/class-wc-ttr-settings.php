<?php
defined( 'ABSPATH' ) or exit;

/**
 * Set up the admin settings.
 *
 * @since 1.0.0
 */
class WC_TTR_Settings {


	protected $id = 'ttr';


	public function __construct() {
		
		add_filter( 'woocommerce_get_sections_tax', array( $this, 'add_settings_section' ) );

		add_action( 'woocommerce_get_settings_tax', array( $this, 'add_settings' ) );

		add_action( 'woocommerce_settings_save_tax', array( $this, 'save_settings' ) );
		
	}

	public function add_settings_section( $sections ) {

		$sections[ $this->id ] = __( 'TTR', 'woocommerce-ttr' );

		return $sections;
	}


	public function get_api_settings() {

		$connection_status = get_transient( 'wc_ttr_connection_status' );

		$settings = array(

			

			array(
				'name' => __( 'API Settings', 'woocommerce-ttr' ),
				'type' => 'title',
				'desc' => sprintf(
					__( 'Log in to your munirevs %1$sAdmin Console%2$s to find your connection information.', 'woocommerce-ttr' ),
					'<a href="https://colorado.munirevs.com/" target="_blank">',
					'</a>'
				),
			),
			


			array(
				'id'                => 'wc_ttr_api_license_key',
				'name'              => __( 'API Key', 'woocommerce-ttr' ),
				'type'              => 'text',
				'class'             => 'wc-ttr-connection-field',
				'css'               => 'min-width:300px;',
				'custom_attributes' => array(
					'data-wc-ttr-connection-status' => $connection_status,
				),
			),

		

			array(
				'id'                => 'wc_ttr_api_tax_breakdown',
				'name'              => __( 'Breakdown Taxes by Jurisdiction [Beta]', 'wc_ttr_api_tax_breakdown' ),
				'type'              => 'checkbox',
				'class'             => 'wc_ttr_api_tax_breakdown',
				'css'               => 'min-width:300px;',
				
			),
			array(
				'type' => 'sectionend',
			),
		);

		return (array) apply_filters( 'woocommerce_get_settings_' . $this->id . '_api', $settings );
	}

	public function get_tax_settings() {

		$settings = [

			/*
			[
				'name' => __( 'Settings', 'woocommerce-ttr' ),
				'type' => 'title',
			],
			*/
			/*
			[
				'id'      => 'wc_ttr_calculate_on_cart',
				'title'   => __( 'Cart Calculation [IN DEVELOPMENT]', 'woocommerce-ttr' ),
				'desc'    => __( 'Handling of tax calculations on the cart page', 'woocommerce-ttr' ),
				'type'    => 'select',
				'class'   => 'wc-enhanced-select',
				'css'     => 'min-width: 350px;',
				'options' => [
					'no'    => __( 'Do not show calculations on the cart page', 'woocommerce-ttr' ),
					'yes'   => __( 'Show  tax rates', 'woocommerce-ttr' )
				],
				'default' => 'yes',
			],
*/

			[
				'type' => 'sectionend',
			],
		];

		return (array) apply_filters( 'woocommerce_get_settings_' . $this->id . '_tax_calculation', $settings );
	}

	public function get_address_settings() {

		$settings = array(

			array(
				'type' => 'title',
				'name' => __( 'Address Validation', 'woocommerce-ttr' ),
				'desc' => __( 'Validate shipping addresses at checkout before calculating tax.', 'woocommerce-ttr' ),
			),

			array(
				'id'      => 'wc_ttr_enable_address_validation',
				'name'    => __( 'Enable/Disable', 'woocommerce-ttr' ),
				'desc'    => __( 'Enable ttr address validation', 'woocommerce-ttr' ),
				'default' => 'no',
				'type'    => 'checkbox',
			),

			array(
				'title'   => __( 'Supported Countries', 'woocommerce-ttr' ),
				'id'      => 'wc_ttr_address_validation_countries',
				'class'   => 'wc-enhanced-select',
				'options' => array(
					'US' => __( 'United States (US)', 'woocommerce-ttr' ),
					'CA' => __( 'Canada', 'woocommerce-ttr' ),
				),
				'default' => array(
					'US',
					'CA',
				),
				'type'    => 'multi_select_countries'
			),

			array(
				'id'      => 'wc_ttr_require_address_validation',
				'name'    => __( 'Require for Tax Calculation', 'woocommerce-ttr' ),
				'desc'    => __( 'Require address validation before orders can be placed with calculated tax', 'woocommerce-ttr' ),
				'default' => 'no',
				'type'    => 'checkbox',
			),

			array(
				'type' => 'sectionend',
			),
		);

		return (array) apply_filters( 'woocommerce_get_settings_' . $this->id . '_address_validation', $settings );
	}

	public function get_misc_settings() {

		$settings = array(

			array(
				'type' => 'title',
			),

			array(
				'type' => 'sectionend',
			),
		);

		return apply_filters( 'woocommerce_get_settings_' . $this->id . '_misc', $settings );
	}

	public function get_settings() {

		$settings = array_merge(
			$this->get_api_settings(),
			$this->get_tax_settings(),
			$this->get_misc_settings()
		);

		return apply_filters( 'woocommerce_get_settings_' . $this->id, $settings );
	}

	public function add_settings( $settings ) {

		global $current_section;

		// Output the general settings
		if ( $this->id == $current_section ) {

			// Always display the API settings
			$settings = array_merge(
				$this->get_api_settings(),
				$this->get_misc_settings()
			);


			$settings = array_merge(
				$this->get_tax_settings(),
				$settings
			);

		}

		return $settings;
	}


	/**
	 * Gets the address settings with default fallback values.
	 *
	 * @since 1.7.2
	 *
	 * @param string $setting_id address setting field ID
	 * @return string[] address values
	 */
	private function get_address_values( $setting_id = 'wc_ttr_origin_address' ) {

		$settings         = $this->get_settings();
		$address_defaults = [];
		$address_values   = (array) WC_Admin_Settings::get_option( $setting_id, [] );

		// Loop through each setting to find the address default values.
		foreach ( $settings as $setting ) {

			// The setting ID has to match.
			if ( isset( $setting['id'] ) && $setting_id === $setting['id'] ) {

				$address_defaults = $setting['default'];

				// remove keys that are not present in saved settings
				if ( ! empty( $address_values ) ) {

					// loop through saved address values
					foreach ( $address_defaults as $address_key => $address_value ) {

						if ( ! isset( $address_values[ $address_key ] ) ) {

							unset( $address_defaults[ $address_key ] );
						}
					}
				}

				break;
			}
		}

		return wp_parse_args( $address_values, $address_defaults );
	}


	/**
	 * Display a custom address settings field.
	 *
	 * @since 1.0.0
	 * @param array $options The field options.
	 */
	public function display_address_fields( $options ) {

		$description      = WC_Admin_Settings::get_field_description( $options );
		$tooltip_html     = $description['tooltip_html'];
		$description      = $description['description'];
		$id               = $options['id'];
		$label            = $options['title'];
		$type             = $options['type'];
		$values           = $this->get_address_values( $id );
		$countries        = WC()->countries->countries;
		$selected_country = ( isset( $values['country'] ) ) ? $values['country'] : WC()->countries->get_base_country();

		//include( wc_ttr()->get_plugin_path() . '/includes/admin/views/setting-address.php' );
	}


	/**
	 * Save the settings.
	 *
	 * @since 1.0.0
	 * @global string $current_section The current settings section.
	 */
	public function save_settings() {

		global $current_section;

		// Output the general settings
		if ( $this->id == $current_section ) {

			// If the API credentials were good at last check, save the settings
			if ( 'connected' == get_transient( 'wc_ttr_connection_status' ) ) {
				$this->save_fields( $this->get_tax_settings() );
				$this->save_fields( $this->get_address_settings() );
				$this->save_fields( $this->get_misc_settings() );
			}

			// Always save the API & misc. settings
			$this->save_fields( $this->get_api_settings() );
			$this->save_fields( $this->get_misc_settings() );

			// Reset the API status transient
			delete_transient( 'wc_ttr_connection_status' );
			delete_transient( 'wc_ttr_subscribed' );

		}
	}


	/**
	 * Save the settings fields.
	 *
	 * This is a simple wrapper for `WC_Admin_Settings::save_fields` to intercept our custom "address"
	 * field type for special handling. All other fields are saved as usual. This is being improved in WC 2.4+
	 * but for now this is easiest for older versions.
	 *
	 * @since 1.0.0
	 * @param array $fields The settings fields to save.
	 */
	private function save_fields( $fields ) {

		// Loop through each setting and look for an address field
		foreach ( $fields as $key => $field ) {

			// If found, save it our way and remove it from the settings to save the WooCommerce way
			if ( isset( $field['id'] ) && isset( $field['type'] ) && 'wc_ttr_address' == $field['type'] ) {
				$this->save_address_field( $field );
				unset( $fields[ $key ] );
			}
		}

		WC_Admin_Settings::save_fields( $fields );
	}


	/**
	 * Save the custom address field.
	 *
	 * @since 1.0.0
	 * @param array $field The field definition.
	 */
	private function save_address_field( $field ) {

		$address = isset( $_POST[ $field['id'] ] ) ? wp_unslash( $_POST[ $field['id'] ] ) : array();

		$address = (array) apply_filters( 'wc_ttr_save_address_field', $address );

		$address = array_map( 'wc_clean', $address );

		if ( ! empty( $address ) ) {
			update_option( $field['id'], $address );
		}
	}


}
