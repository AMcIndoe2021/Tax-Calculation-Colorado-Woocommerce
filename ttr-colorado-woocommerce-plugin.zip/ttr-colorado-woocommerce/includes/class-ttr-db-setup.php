<?php
defined( 'ABSPATH' ) or exit;
require_once("../../../../wp-load.php");
require_once( ABSPATH.'wp-admin/includes/upgrade.php' );

global $wpdb;
$charset_collate = $wpdb->get_charset_collate();
$table_name = $wpdb->base_prefix.'ttr_items';
$query = "CREATE TABLE IF NOT EXISTS `$table_name` (
    ID int NOT NULL,
    category VARCHAR(1000) NOT NULL, 
    PRIMARY KEY (ID)
    ) $charset_collate;";

maybe_create_table( $wpdb->prefix . 'ttr_items', $query );

/** For now using this */
$csv_path = WP_PLUGIN_DIR."/ttr-colorado-woocommerce/assets/csv/ColoradoProductsServices.csv";

//Line endings for different OS
ini_set('auto_detect_line_endings',TRUE);
$handle = fopen($csv_path,'r');
while ( ($data = fgetcsv($handle) ) !== FALSE ) {
    if (is_int(intval($data[1])) && $data[1] != 0){
        $sql = $wpdb->prepare( "INSERT INTO `".$table_name."` (ID, category) VALUES ( %s, %s) ON DUPLICATE KEY UPDATE category = '%s'", $data[1], $data[0], $data[0]);
        $wpdb->query($sql);
    }
}
ini_set('auto_detect_line_endings',FALSE);

