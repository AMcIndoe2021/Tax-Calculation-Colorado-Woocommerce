<?php
defined( 'ABSPATH' ) or exit;

//Could be refactored
require_once( ABSPATH.'wp-admin/includes/upgrade.php' );
class DBCreator {
    private $isTableCreated;
    private $csv_path = WP_PLUGIN_DIR."/ttr-colorado-woocommerce/assets/csv/ColoradoProductsServices.csv";
    private $table_name;

    public function __construct(){
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        $this->table_name = $wpdb->base_prefix.'ttr_items';
        $query = "CREATE TABLE  `$this->table_name` (
            ID int NOT NULL,
            category VARCHAR(1000) NOT NULL, 
            PRIMARY KEY (ID)
            ) $charset_collate;";

        $this->isTableCreated = maybe_create_table( $wpdb->prefix . 'ttr_items', $query );
    }

    public function createDBIfNotExists(){
        if ($this->isTableCreated){
            global $wpdb;
        /** For now using this */
           

            //Line endings for different OS
            if (ini_get('auto_detect_line_endings') == FALSE){

                ini_set('auto_detect_line_endings',TRUE);
            }
    
            $handle = fopen($this->csv_path,'r');
            while ( ($data = fgetcsv($handle) ) !== FALSE ) {
                if (is_int(intval($data[1])) && $data[1] != 0){
                    $sql = $wpdb->prepare( "INSERT INTO `".$this->table_name."` (ID, category) VALUES ( %s, %s) ON DUPLICATE KEY UPDATE category = '%s'", $data[1], $data[0], $data[0]);
                    $wpdb->query($sql);
                }
            }
            ini_set('auto_detect_line_endings',FALSE);

        }
}
}