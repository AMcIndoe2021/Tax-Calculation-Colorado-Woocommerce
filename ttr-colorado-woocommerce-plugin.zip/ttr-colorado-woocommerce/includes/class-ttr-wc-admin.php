<?php


defined( 'ABSPATH' ) or exit;

/**
 * Set up the AvaTax admin.
 *
 * @since 1.0.0
 */
class WC_TTR_Admin {
    protected $options;
	protected $checkout;
	public function __construct() {

		require_once( plugin_dir_path( __FILE__ ) . '/class-ttr-db-setup.php' );
		
		$dbSetup = new DBCreator();
		$dbSetup->createDBIfNotExists();

		$this->includes();
		// display the tax code field
		add_action( 'woocommerce_product_options_tax', array( $this, 'display_tax_code_field' ) );
        // save the product field values
        add_action( 'woocommerce_process_product_meta', array( $this, 'save_meta' ), 10, 2 );

		

	}


	public function includes() {
       
        require_once( plugin_dir_path( __FILE__ ) . '/admin/class-wc-ttr-settings.php' );
		$this->settings = new WC_TTR_Settings;

		require_once(plugin_dir_path(__FILE__).'/admin/api/class-wc-ttr-checkout-handler.php');
		$this->checkout = new WC_TTR_Checkout_Handler();
    }

	public function display_tax_code_field() {

		woocommerce_wp_select(
			array(
				'id'            => '_wc_ttr_code',
				'wrapper_class' => 'hide_if_external',
				'label'         => __( 'TTR Item Code', 'woocommerce-ttr' ),
                'options'       => $this->get_item_mapping(),
			)
		);
	}

    public function get_item_mapping(){
        global $wpdb;
        $results = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}ttr_items",ARRAY_A);
		if (!$results){
			require_once( plugin_dir_path( __FILE__ ) . '/class-ttr-db-setup.php' );
			return;
		}
        
        foreach ($results as $item){
            $this->options[$item['ID']] = $item['category'];           
        }
        asort($this->options);
        return $this->options;

    }

	public function save_meta( $post_id ) {
        $item = (string) $this::get_posted_value( '_wc_ttr_code');

		update_post_meta( $post_id, '_wc_ttr_code', sanitize_text_field( $this::get_posted_value( '_wc_ttr_code' ) ) );

    }


	public static function get_posted_value( $key, $default = '' ) {

		$value = $default;

		if ( isset( $_POST[ $key ] ) ) {
			$value = is_string( $_POST[ $key ] ) ? trim( $_POST[ $key ] ) : $_POST[ $key ];
		}

		return $value;
	}
    
}
